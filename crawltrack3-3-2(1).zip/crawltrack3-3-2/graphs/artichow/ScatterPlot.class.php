<?php
require_once dirname(__FILE__).'/Artichow.cfg.php';
require_once ARTICHOW.'/ScatterPlot.class.php';
?>