Crawltrack 3.3.2

README
------

-First installation:

Once the files upload on your website, you just have to enter your CrawlTrack url in your
browser and follow the instructions to install CrawlTrack.
You will find more details information on the official website : http://www.crawltrack.net

-Upgrade from a previous version:

Upload on your website all the new files, taking care not to destroy the crawltrack.php file at the root
of your crawltrack folder and the configconnect.php file in the include folder.
Thats all what you have to do. You will keep all your datas, just the config will be updated.

If you are using the second tag (the biggest one with http request) from a version before the 3.0.0, you need to replace the tag on your page
to be able to use that version.

Once Crawltrack install, don't forget to add your site to the Crawltrack users directory:
http://www.crawltrack.net/user-list/english.html



LISEZ MOI
---------

-Premi�re installation:

Une fois les fichier upload�s sur votre site, il suffit d'entrer l'adresse de votre crawltrack
dans votre navigateur et de suivre les instructions pour installer Crawltrack.
Vous trouverez des informations plus d�taill�es sur le site officiel: http://www.crawltrack.net/fr

-Mise � jour � partir d'une version pr�c�dente:

Uploadez sur votre site les nouveaux fichiers, en prenant garde de ne pas �craser le fichier crawltrack.php � la racine
du r�pertoire crawltrack et le fichier configconnect.php dans le r�pertoire include.
C'est tout ce que vous avez � faire. Vos donn�es sont conserv�es, seul la configuration sera mise � jour.

Si vous utilisiez le deuxi�me tag (le plus long, avec la requ�te http) d'une version avant la 3.0.0, il faut remplacer
le tag Crawltrack sur vos pages pour pouvoir utiliser cette version.

Une fois CrawlTrack install�, n'oubliez pas d'inscrire votre site dans l'annuaire des utilisateurs de Crawltrack:
http://www.crawltrack.net/user-list/french.html
